//~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ 

//~ ~ ~ ~ TABLE OF CONTENTS~ ~ ~ ~
    //~ ~ SETTINGS OPTIONS ~ ~
        // ~ Font Type
        // ~ Font Size
        // ~ Line Height
        // ~ Text Alignment
        // ~ Theme
        // ~ Volume
        // ~ Animation Toggle
        // ~ Notification Toggle
        // ~ Autosave Toggle
        // ~ Autoname Toggle
    //~ ~ MACROS ~ ~
        // ~ Notify
        
//~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ 

//~ ~ ~ ~ SETTINGS OPTIONS ~ ~ ~ ~
    /*
    Notes:
        ~ Settings are shown in a first-coded first-shown manner. If you prefer to organise it in a different manner, you can always move the code around.
        ~ You can also add or remove settings, to fit what your project needs.
        ~ Below seems to be the ones most found or requested in IF circles.
    */

    //~ ~ ~ ~ TEXT DYSPLAY ~ ~ ~ ~
Setting.addHeader("Text Display", "Below are settings controlling how the text is displayed");
    /*
    Note:
        ~ Headers are coded like this: Setting.addHeader(name [, description]), where the description is optional.
        ~ Further down this page is a header without a description.
    */
        
        //~ ~ Font Type ~ ~
var settingFontFamily = ["Serif", "Sans Serif", "OpenDyslexic"]; //Visible options, you can add or remove them (each should be separated by a comma)
var fontFamily = function() {
var $html = $("html"); 
    $html.removeClass("serif sansserif opendyslexic"); //this will remove the old CSS font tag used before the switch
switch (settings.fontFamily) { //this part will add the new CSS font tag to the page depending on the player choice
    case "Serif": //this name should be the same than in the option defined in the first line
        $html.addClass("serif"); //each of these options need to be set in the StyleSheet (CSS)
        break;
    case "Sans Serif":
        $html.addClass("sansserif");
        break;
    case "OpenDyslexic":
        $html.addClass("opendyslexic");
        break;
    /*
    To add a new font to the list:
        ~ Add the Name of the new option inside > var settingFontFamily
        ~ Add a CSS font tag inside > $html.removeClass
        ~ Add another case inside > switch (settings.fontFamily)

        case "Font Option"
            $html.addClass("css-tag-for-the-new-font");
            break;
    */
}};
Setting.addList("fontFamily", {//This is the actual Setting visible to the player
    label		: "Change font type",
    desc        : "Choose between a Serif, Sans-serif, or the OpenDyslexic Font", //This line is optional
    list		: settingFontFamily,
    default     : "Serif", //If you remove this, the system will pick the first defined option
    onInit		: fontFamily,
    onChange	: fontFamily
});	


        //~ ~ Font Size ~ ~
    /*
        Note: The code below links the #passages ID to the CSS font-size rule. 
        You can also choose to create a setting like the one above with a new CSS class, and set the class manually in the CSS.
    */
var settingFontSize = ["75%", "100%", "125%", "150%"];
var resizeFont = function() {
var size = document.getElementById("passages"); //This is linked to #passages in the CSS
switch (settings.fontSize) {
    case "100%":
        size.style.fontSize = "100%"; //You can use other value units, like px, em, or absolute ones (small, large...)
        break;
    case "75%":
        size.style.fontSize = "75%";
        break;
    case "125%":
        size.style.fontSize = "125%";
        break;
    case "150%":
        size.style.fontSize = "150%";
        break;
}
};
Setting.addList("fontSize", {
    label		: "Change Font Size",
    list		: settingFontSize,
    default     : "100%",
    onInit		: resizeFont,
    onChange	: resizeFont
});


        //~ ~ Line Height ~ ~
var settingLineHeight = ["75%", "100%", "125%", "150%"];
var lineHeight = function () {
var $html = $("html");
$html.removeClass("lh-small lh-medium lh-large lh-biggest");
switch (settings.lineheight) {
    case "75%":
        $html.addClass("lh-small");
        break;
    case "100%":
        $html.addClass("lh-medium");
        break;	
    case "125%":
        $html.addClass("lh-large");
        break;	
    case "150%":
        $html.addClass("lh-biggest");
        break;	
}};
Setting.addList("lineheight", {
    label       : "Change Line Height",
    default     : "100%",
    list        : settingLineHeight,
    onInit      : lineHeight,
    onChange    : lineHeight
});
        
        //~ ~ Text Alignment ~ ~
    /*
        Note: If you want more than justifed/left alignment, you can create a setting like the Font Change, and add centered/right alignment options.
    */
var settingtextAlign = function () {
    if (settings.textalign) { // is true
        $("html").addClass("justified");
    } else { // is false
        $("html").removeClass("justified");
}};
Setting.addToggle("textalign", {
    label       : "Change Text Alignment",
    desc        : "If enabled, the text will be justified",
    default     : false,
    onInit      : settingtextAlign,
    onChange    : settingtextAlign
});

//~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ 

    //~ ~ ~ ~ SOUND/THEME ~ ~ ~ ~
Setting.addHeader("Mode and Volume");

        //~ ~ Theme ~ ~
var settingThemeNames = ["Light", "Dark"]; 
    //If you only have two themes, you could consider to make it a toggle rather than a list
var changeTheme = function () {
    var $html = $("html");
    $html.removeClass("rev");
    switch (settings.theme) {
        case "Dark":
            $html.addClass("rev");
            break;
}};
Setting.addList("theme", {
    label       : "Switch display mode",
    list        : settingThemeNames,
    default	    : "Dark",
    onInit      : changeTheme,
    onChange    : changeTheme
});

        //~ ~ Volume ~ ~
Setting.addRange("masterVolume", {
	label       : "Volume Level.",
	min         : 0,
	max         : 10,
	step        : 1,
	onChange    : function () {SimpleAudio.volume(settings.masterVolume / 10);}
});

//~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ 


    //~ ~ ~ ~ OTHER ACCESSIBILITY ~ ~ ~ ~
Setting.addHeader("Accessibility");

        //~ ~ Animation Toggle ~ ~
var settingAnimation = function () {
    if (settings.textanim) { // is true
        $("html").removeClass("nogif");
    } else { // is false
        $("html").addClass("nogif");
}};
Setting.addToggle("textanim", {
    label       : "Show Animated Items",
    desc        : "If disabled, there will be no animation on the page",
    default     : true,
    onInit      : settingAnimation,
    onChange    : settingAnimation
});
        //~ ~ Notification Toggle ~ ~
    /*
        Note:
        ~ Depending on how the notifications are coded in your game (or what macro you are using), you may want to create a CSS class instead (like with the animation toggle above).
        ~ You can also combine both this setting and the one above into one.
    */
Setting.addToggle("notif", { 
    label       : "Show Notification",
    desc        : "If disabled, you will not be notified.",
    default     : true,
});


//~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ 

    //~ ~ ~ ~ SAVING (Auto/Name) ~ ~ ~ ~
Setting.addHeader("Save Settings");


Config.saves.isAllowed = function () {
    if (tags().includes('noreturn')) { 
        //Does not allow ANY saving (auto or manual) when a passage is tagged with noreturn (for title page)
        return false;
    }
    return true;
};

        //~ ~ Autosave Toggle ~ ~
Config.saves.autosave = function () {
    if (settings.autosave) {
        return true //this will save at every passage (not tagged noreturn)
}};
Setting.addToggle("autosave", {
    label       : "Autosaves",
    default     : false,
});

        //~ ~ Autoname Toggle ~ ~
Save.onSave.add( function (save, details) {
    if (settings.autoname) {
        //The title of the save will be the first and last name of the player (you can change the name of the variable), or question marks if the variable are not defined.
        save.title = (State.getVar("$FirstName") ? State.getVar("$FirstName") : '???');
            //This is essentially asking if the variable is defined ? if yes show this - otherwise (:) show that
        /*
            If you want to the include the passage name in the save you can use something like this:
                Config.passages.descriptions = true;
                    In this casem the passage name should be meaningful (so "Entrance to Manor" rather than "Ch10-2")

            Or if you are tracking chapters (in the $chapter variable):
                save.title = 'Chapter ' + State.variables.chapter + ' bookmark';
                    State.variables.chapter is the same as State.getVar("$chapter")
                
        */
    } else if (details.type == "autosave") {
        //If Autoname is disabled but the autosave is enabled, this will be the name of the autosave
        save.title = "Autosave";
    } else {
        //This will prompt the player to enter a name for the save file
        save.title = prompt("Enter Save Name:", save.title);
}});

Setting.addToggle("autoname", {
    label       : "Autoname",
    desc        : "description of title if enabled",
    default     : false,
});


//~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ 

    //~ ~ ~ ~ MACROS ~ ~ ~ ~
// notify.min.js, for SugarCube 2, by Chapel
// v1.1.1, 2022-07-21, 3bdbdfbe5ae47a46e4f4e52766d78701939ae9a6
;!function(){var s=/\d+m?s$/;function e(s,e,t){"string"==typeof s&&("number"!=typeof e&&(e=!1),$(document).trigger({type:":notify",message:s,delay:e,class:t||""}))}$(document.body).append("<div id='notify'></div>"),$(document).on(":notify",(function(s){s.message&&"string"==typeof s.message&&(s.message.trim(),s.class?"string"==typeof s.class?s.class="open macro-notify "+s.class:Array.isArray(s.class)?s.class="open macro-notify "+s.class.join(" "):s.class="open macro-notify":s.class="open macro-notify",s.delay?("number"!=typeof s.delay&&(s.delay=Number(s.delay)),Number.isNaN(s.delay)&&(s.delay=2e3)):s.delay=2e3,$("#notify").empty().wiki(s.message).addClass(s.class),setTimeout((function(){$("#notify").removeClass()}),s.delay))})),Macro.add("notify",{tags:null,handler:function(){var t=this.payload[0].contents,a=!1,n=!1;if(this.args.length>0){var i=s.test(this.args[0]);"number"==typeof this.args[0]||i?(a=i?Util.fromCssTime(this.args[0]):this.args[0],n=this.args.length>1&&this.args.slice(1).flatten()):n=this.args.flatten().join(" ")}e(t,a,n)}}),setup.notify=e}();
// end notify.min.js